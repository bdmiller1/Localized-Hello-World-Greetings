# calculate the radius (firstname) of a cirle + volume of a sphere
# calculate side (lastname) area of a square + volume of a cube
def ask(lang, first, last):
    answer = len(first)
    answer2 = len(last)
    pi = 3.14
    if lang == 'e' or lang == 'E':
        print("Your first name is " + str(answer) + " characters long.")
        print("what is the area of a circle using your first name?")
        print("The area of the circle using your first name as the radius is, " + str(pi * answer **2))
        print("your radius is " + str(answer) +  ". And the area of this cirlce is " + str(answer **2 *pi))
        print("The volume of the sphere using your first name as the radius is, " + str(4/3*pi*answer**3))
        print("The are of a square using the length of your last name as a side is, " + str(answer2*answer2))
        print("The volume of a cube using the length of your last is, " + str(answer2**3))
    elif lang == 'f' or lang == 'F':
        print("Votre prénom est " + str(answer) + " caractères longs.")
        print("Quelle est la zone d’un cercle utilisant votre prénom ?")
        print("La zone du cercle utilisant votre prénom comme rayon est, " + str(pi * answer **2))
        print("votre rayon est " + str(answer) +  ". Et la zone de cette cirlce est " + str(answer **2 *pi))
        print("Le volume de la sphère utilisant votre prénom comme rayon est, " + str(4/3*pi*answer**3))
        print("Le sont d’un carré en utilisant la longueur de votre nom de famille comme un côté est, " + str(answer2*answer2))
        print("Le volume d’un cube utilisant la longueur de votre dernier est, " + str(answer2**3))
    elif lang == 's' or lang == 'S':
        print("Su nombre de pila es " + str(answer) + " caracteres largos.")
        print("¿Cuál es el área de un círculo usando su nombre?")
        print("El área del círculo que usa su nombre de pila como radio es, " + str(pi * answer **2))
        print("Su radio es " + str(answer) +  ". Y el área de este cirlce es " + str(answer **2 *pi))
        print("El volumen de la esfera usando su nombre de pila como radio es, " + str(4/3*pi*answer**3))
        print("El son de un cuadrado usando la longitud de su apellido como un lado es, " + str(answer2*answer2))
        print("El volumen de un cubo usando la longitud de su último es, " + str(answer2**3))
