# Bahna Miller's Python Assignment#3
import purple, orange,green
lang,firstname,lastname=orange.greeting(purple.languagepicker())
green.ask(lang,firstname,lastname)
