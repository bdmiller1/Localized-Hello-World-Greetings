# localized name request
def greeting(lang):
    # works with lowercase but not with uppercase. Or does it?
    if lang == 'e'or lang == 'E':
        print("What is your first name?")
        first = input()
        print("What is your last name?")
        last = input()
        print("Nice to meet you, " + first + " " + last)
    elif lang == 's'or lang == 'S':
        print("¿Cuál es tu nombre de pila?")
        first = input()
        print("¿Cuál es tu apellido?")
        last = input()
        print("Hola, " + first + " " + last)
    elif lang == 'f'or lang == 'F':
        print("Qu'est-ce que votre prénom?")
        first = input()
        print("Qu'est-ce que votre nom?")
        last = input()
        print("Salut, " + first + " " + last)
    else:
        print("Not so good at typing, hunh?")
        print("I should do something else here, right? With the " + lang + "... You know...")
    return lang, first, last
