# Language option and greeting (localized)
def languagepicker():

    lang = False
    while not lang:
        print("Please select a language: (E)nglish, (S)panish, or (F)rench?")
        language = input()
        lang = language[0]

# works with lowercase but not with uppercase. Or does it?
        if lang == 'e'or lang == 'E':
            print("English")
            print("Hello, World!")
        elif lang == 's'or lang == 'S':
            print("Spanish")
            print("Hola mundo!")
        elif lang == 'f'or lang == 'F':
            print("French")
            print("Bonjour à toutes et à tous !")
        else:
            print ("This is not Duolingo. Only select the languages mentioned above.")
            lang = False
        return lang
